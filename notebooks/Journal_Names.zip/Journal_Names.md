# Journal Names

Questions in the context of fuzzy matching.

* How many journal names appear more than once?
* What is the average length of the duplicated names vs the unique names?


Input file is a single larger JSON, mapping names to issns.
```json
{
  "Acta Orientalia.": [
    "0001-6438"
  ],
  "Acta Orientalia (København)": [
    "0001-6438"
  ],
..
```


```python
import json
import pandas as pd
```


```python
with open("../data/name_to_issn.json") as f:
    mapping = json.load(f)

```

We have about 3M keys.


```python
len(mapping)
```




    2929727




```python
df = pd.DataFrame(((k, len(v)) for k, v in mapping.items()), columns=["name", "issn_count"])
```


```python
len(df)
```




    2929727




```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>name</th>
      <th>issn_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Acta Orientalia.</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Acta Orientalia (København)</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>The publishers weekly.</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Publishers weekly</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>ASMT news</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
unique_name = df[df.issn_count == 1]
```


```python
repeated_names = df[df.issn_count > 1]
```


```python
len(repeated_names)
```




    194241




```python
len(repeated_names) / len(df)
```




    0.06630003409874026



About 6% (or 194241) names are repeated. 


```python
repeated_names.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>issn_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>194241.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>3.197523</td>
    </tr>
    <tr>
      <th>std</th>
      <td>25.081605</td>
    </tr>
    <tr>
      <th>min</th>
      <td>2.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>2.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>2.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>2.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>8980.000000</td>
    </tr>
  </tbody>
</table>
</div>



Which name is shared by over 8000 ISSN?


```python
repeated_names.iloc[repeated_names.issn_count.argmax()] # Annual report.
```




    name          Annual report.
    issn_count              8980
    Name: 45907, dtype: object



It is the "Annual report."


```python
mapping["Annual report."][:10]
```




    ['0706-537X',
     '1186-7957',
     '2324-1926',
     '1445-9248',
     '0872-3982',
     '1714-1524',
     '1037-8812',
     '0225-0241',
     '1327-6344',
     '0702-7702']



On average a repeated name will point to 3 ISSN. About 24k names point to more than 3 ISSN.


```python
len(repeated_names[repeated_names.issn_count > 3])
```




    24107




```python
repeated_names[repeated_names.issn_count > 3].sample(n=10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>name</th>
      <th>issn_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>322100</th>
      <td>Philosophica.</td>
      <td>17</td>
    </tr>
    <tr>
      <th>183928</th>
      <td>Edad de oro.</td>
      <td>4</td>
    </tr>
    <tr>
      <th>294309</th>
      <td>Horoskop.</td>
      <td>10</td>
    </tr>
    <tr>
      <th>517039</th>
      <td>Le Grand journal.</td>
      <td>11</td>
    </tr>
    <tr>
      <th>1664616</th>
      <td>Caleidoscop şcolar.</td>
      <td>4</td>
    </tr>
    <tr>
      <th>258430</th>
      <td>La Feuille.</td>
      <td>34</td>
    </tr>
    <tr>
      <th>309546</th>
      <td>The Wilson quarterly.</td>
      <td>4</td>
    </tr>
    <tr>
      <th>795859</th>
      <td>Introductory research essay</td>
      <td>4</td>
    </tr>
    <tr>
      <th>1470838</th>
      <td>Publicaciones del SEMYR.</td>
      <td>4</td>
    </tr>
    <tr>
      <th>657041</th>
      <td>Le Kiosque.</td>
      <td>14</td>
    </tr>
  </tbody>
</table>
</div>




```python
mapping["Philosophica."]
```




    ['1285-9133',
     '1480-4670',
     '1487-5349',
     '1724-6598',
     '2183-0134',
     '2538-693X',
     '2610-8933',
     '2035-8326',
     '2295-9084',
     '1517-8889',
     '2249-5053',
     '2420-9198',
     '2654-9263',
     '2610-8925',
     '1158-9574',
     '0872-4784',
     '0379-8402']




```python
repeated_names[repeated_names.issn_count > 3].issn_count.hist(bins=20)
```




    <AxesSubplot:>




![png](output_22_1.png)



```python
repeated_names[(repeated_names.issn_count > 3) & (repeated_names.issn_count < 50)].issn_count.hist(bins=10)
```




    <AxesSubplot:>




![png](output_23_1.png)



```python
repeated_names[(repeated_names.issn_count > 3) & (repeated_names.issn_count < 20)].issn_count.hist(bins=10)
```




    <AxesSubplot:>




![png](output_24_1.png)



```python
repeated_names[(repeated_names.issn_count > 3) & (repeated_names.issn_count < 8)].issn_count.hist()
```




    <AxesSubplot:>




![png](output_25_1.png)



```python
repeated_names[repeated_names.issn_count > 1000].issn_count.hist(bins=10)
```




    <AxesSubplot:>




![png](output_26_1.png)



```python
repeated_names[repeated_names.issn_count > 1000]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>name</th>
      <th>issn_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>3499</th>
      <td>Bulletin.</td>
      <td>2752</td>
    </tr>
    <tr>
      <th>7632</th>
      <td>Newsletter.</td>
      <td>2715</td>
    </tr>
    <tr>
      <th>8317</th>
      <td>Rapport.</td>
      <td>1050</td>
    </tr>
    <tr>
      <th>23662</th>
      <td>Proceedings.</td>
      <td>1403</td>
    </tr>
    <tr>
      <th>45839</th>
      <td>Annual report /</td>
      <td>1090</td>
    </tr>
    <tr>
      <th>45907</th>
      <td>Annual report.</td>
      <td>8980</td>
    </tr>
    <tr>
      <th>45964</th>
      <td>Annuaire.</td>
      <td>1260</td>
    </tr>
    <tr>
      <th>47217</th>
      <td>Rapport annuel.</td>
      <td>2656</td>
    </tr>
  </tbody>
</table>
</div>




```python
repeated_names[repeated_names.issn_count > 500]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>name</th>
      <th>issn_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>102</th>
      <td>Bulletin d'information.</td>
      <td>693</td>
    </tr>
    <tr>
      <th>3218</th>
      <td>Bulletin de liaison.</td>
      <td>510</td>
    </tr>
    <tr>
      <th>3499</th>
      <td>Bulletin.</td>
      <td>2752</td>
    </tr>
    <tr>
      <th>7632</th>
      <td>Newsletter.</td>
      <td>2715</td>
    </tr>
    <tr>
      <th>8317</th>
      <td>Rapport.</td>
      <td>1050</td>
    </tr>
    <tr>
      <th>23662</th>
      <td>Proceedings.</td>
      <td>1403</td>
    </tr>
    <tr>
      <th>45794</th>
      <td>Report.</td>
      <td>743</td>
    </tr>
    <tr>
      <th>45839</th>
      <td>Annual report /</td>
      <td>1090</td>
    </tr>
    <tr>
      <th>45907</th>
      <td>Annual report.</td>
      <td>8980</td>
    </tr>
    <tr>
      <th>45964</th>
      <td>Annuaire.</td>
      <td>1260</td>
    </tr>
    <tr>
      <th>46370</th>
      <td>Jaarverslag.</td>
      <td>675</td>
    </tr>
    <tr>
      <th>47142</th>
      <td>Rapport d'activité.</td>
      <td>660</td>
    </tr>
    <tr>
      <th>47217</th>
      <td>Rapport annuel.</td>
      <td>2656</td>
    </tr>
    <tr>
      <th>49289</th>
      <td>Jahresbericht.</td>
      <td>518</td>
    </tr>
    <tr>
      <th>57558</th>
      <td>Annual report</td>
      <td>760</td>
    </tr>
    <tr>
      <th>121599</th>
      <td>Alumni directory /</td>
      <td>511</td>
    </tr>
    <tr>
      <th>128827</th>
      <td>Bulletin municipal.</td>
      <td>521</td>
    </tr>
    <tr>
      <th>150529</th>
      <td>La Lettre.</td>
      <td>623</td>
    </tr>
    <tr>
      <th>168933</th>
      <td>Local climatological data.</td>
      <td>613</td>
    </tr>
    <tr>
      <th>269004</th>
      <td>Estimates.</td>
      <td>535</td>
    </tr>
  </tbody>
</table>
</div>




```python
repeated_names[repeated_names.issn_count > 200]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>name</th>
      <th>issn_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>102</th>
      <td>Bulletin d'information.</td>
      <td>693</td>
    </tr>
    <tr>
      <th>2665</th>
      <td>Newsletter /</td>
      <td>259</td>
    </tr>
    <tr>
      <th>3218</th>
      <td>Bulletin de liaison.</td>
      <td>510</td>
    </tr>
    <tr>
      <th>3499</th>
      <td>Bulletin.</td>
      <td>2752</td>
    </tr>
    <tr>
      <th>3926</th>
      <td>Boletín.</td>
      <td>216</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>425644</th>
      <td>Rapport d'activité ...</td>
      <td>394</td>
    </tr>
    <tr>
      <th>532500</th>
      <td>Relatório e contas.</td>
      <td>247</td>
    </tr>
    <tr>
      <th>603144</th>
      <td>Bildung und Beruf regional.</td>
      <td>292</td>
    </tr>
    <tr>
      <th>1006131</th>
      <td>Vies de famille.</td>
      <td>222</td>
    </tr>
    <tr>
      <th>1110247</th>
      <td>Country risk service.</td>
      <td>271</td>
    </tr>
  </tbody>
</table>
<p>66 rows × 2 columns</p>
</div>




```python
repeated_names[repeated_names.issn_count > 100]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>name</th>
      <th>issn_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>102</th>
      <td>Bulletin d'information.</td>
      <td>693</td>
    </tr>
    <tr>
      <th>2665</th>
      <td>Newsletter /</td>
      <td>259</td>
    </tr>
    <tr>
      <th>3218</th>
      <td>Bulletin de liaison.</td>
      <td>510</td>
    </tr>
    <tr>
      <th>3499</th>
      <td>Bulletin.</td>
      <td>2752</td>
    </tr>
    <tr>
      <th>3926</th>
      <td>Boletín.</td>
      <td>216</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1306798</th>
      <td>Country commerce.</td>
      <td>120</td>
    </tr>
    <tr>
      <th>1318569</th>
      <td>Bible studies for life.</td>
      <td>159</td>
    </tr>
    <tr>
      <th>1796742</th>
      <td>LexisNexis practice guide.</td>
      <td>101</td>
    </tr>
    <tr>
      <th>2628387</th>
      <td>Operational risk report.</td>
      <td>119</td>
    </tr>
    <tr>
      <th>2650557</th>
      <td>Interempresas net.</td>
      <td>108</td>
    </tr>
  </tbody>
</table>
<p>191 rows × 2 columns</p>
</div>




```python
repeated_names
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>name</th>
      <th>issn_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>5</th>
      <td>Activitas Nervosa Superior.</td>
      <td>2</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Library journal.</td>
      <td>2</td>
    </tr>
    <tr>
      <th>23</th>
      <td>Acta cardiologica.</td>
      <td>2</td>
    </tr>
    <tr>
      <th>26</th>
      <td>Actualidad económica.</td>
      <td>3</td>
    </tr>
    <tr>
      <th>31</th>
      <td>Acta Ornithologica.</td>
      <td>3</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>2929626</th>
      <td>Modern machine shop México.</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2929635</th>
      <td>Lecture notes in control and information scien...</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2929646</th>
      <td>Critical Studies in Dance Leadership and Inclu...</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2929691</th>
      <td>Nigerian Journal of Wildlife Management</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2929702</th>
      <td>Verzeichniss der Kunstwerke lebender Künstler,...</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
<p>194241 rows × 2 columns</p>
</div>



If a name matches a repeated name exactly or fuzzy matches to a repeated name and there is not other information available, the match status must be ambigious.


```python

```
